/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/components/ActionButton`; params?: Router.UnknownInputParams; } | { pathname: `/components/FokusButton`; params?: Router.UnknownInputParams; } | { pathname: `/components/Icons`; params?: Router.UnknownInputParams; } | { pathname: `/components/Timer`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/components/ActionButton`; params?: Router.UnknownOutputParams; } | { pathname: `/components/FokusButton`; params?: Router.UnknownOutputParams; } | { pathname: `/components/Icons`; params?: Router.UnknownOutputParams; } | { pathname: `/components/Timer`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/components/ActionButton${`?${string}` | `#${string}` | ''}` | `/components/FokusButton${`?${string}` | `#${string}` | ''}` | `/components/Icons${`?${string}` | `#${string}` | ''}` | `/components/Timer${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/components/ActionButton`; params?: Router.UnknownInputParams; } | { pathname: `/components/FokusButton`; params?: Router.UnknownInputParams; } | { pathname: `/components/Icons`; params?: Router.UnknownInputParams; } | { pathname: `/components/Timer`; params?: Router.UnknownInputParams; };
    }
  }
}
